package com.wordweb.dto.story;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StoryDetailResponse {

    private Long storyId;
    private String title;
    private String storyEn;
    private String storyKo;
    private LocalDateTime createdAt;   // ★ 매우 중요!
    private List<WordInfo> words;

    @Getter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class WordInfo {
        private Long wordId;
        private String word;
        private String meaning;
        private String partOfSpeech;
        private String category;
        private Integer level;
    }
}
