package com.wordweb.entity;

import jakarta.persistence.*;
import lombok.*;
import java.sql.Timestamp;

@Entity
@Table(name = "WORD")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Word {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "WORD_ID")
    private Long wordId;

    @Column(name = "WORD", nullable = false, unique = true)
    private String word;

    @Column(name = "MEANING", nullable = false)
    private String meaning;

    @Column(name = "PART_OF_SPEECH")
    private String partOfSpeech;

    @Lob
    @Column(name = "EXAMPLE_SENTENCE_EN")
    private String exampleSentenceEn;

    @Lob
    @Column(name = "EXAMPLE_SENTENCE_KO")
    private String exampleSentenceKo;

    @Column(name = "CATEGORY")
    private String category;

    @Column(name = "WORD_LEVEL")
    private Integer level;
    
    @Lob
    @Column(name = "EMBEDDING")
    private String embedding;

    @Column(name = "CREATED_AT")
    private Timestamp createdAt;
}
