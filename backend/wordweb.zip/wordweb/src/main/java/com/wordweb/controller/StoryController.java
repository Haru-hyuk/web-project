package com.wordweb.controller;

import com.wordweb.dto.story.StoryDetailResponse;
import com.wordweb.service.StoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/stories")
@RequiredArgsConstructor
public class StoryController {

    private final StoryService storyService;

    /** 스토리 상세 조회 */
    @GetMapping("/{storyId}")
    public ResponseEntity<StoryDetailResponse> getStoryDetail(@PathVariable Long storyId) {
        return ResponseEntity.ok(storyService.getStoryDetail(storyId));
    }
}
