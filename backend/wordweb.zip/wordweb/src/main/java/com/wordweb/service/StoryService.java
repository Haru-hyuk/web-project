package com.wordweb.service;

import com.wordweb.dto.story.StoryDetailResponse;
import com.wordweb.entity.StoryWordList;
import com.wordweb.entity.WrongAnswerStory;
import com.wordweb.repository.StoryWordListRepository;
import com.wordweb.repository.WrongAnswerStoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class StoryService {

    private final WrongAnswerStoryRepository wrongAnswerStoryRepository;
    private final StoryWordListRepository storyWordListRepository;

    /** 스토리 상세 조회 + Word 목록 반환 */
    public StoryDetailResponse getStoryDetail(Long storyId) {

        WrongAnswerStory story = wrongAnswerStoryRepository.findById(storyId)
                .orElseThrow(() -> new RuntimeException("Story not found"));

        // Word를 JOIN FETCH로 불러오는 쿼리 사용 (LAZY 방지)
        List<StoryWordList> list =
                storyWordListRepository.findByStoryIdWithWord(storyId);

        List<StoryDetailResponse.WordInfo> words =
                list.stream()
                        .map(swl -> StoryDetailResponse.WordInfo.builder()
                                .wordId(swl.getWord().getWordId())
                                .word(swl.getWord().getWord())
                                .meaning(swl.getWord().getMeaning())
                                .partOfSpeech(swl.getWord().getPartOfSpeech())
                                .category(swl.getWord().getCategory())
                                .level(swl.getWord().getLevel())
                                .build()
                        )
                        .toList();

        return StoryDetailResponse.builder()
                .storyId(story.getStoryId())
                .title(story.getTitle())
                .storyEn(story.getStoryEn())
                .storyKo(story.getStoryKo())
                .createdAt(story.getCreatedAt())   // ★ 추가됨
                .words(words)
                .build();

    }
}
