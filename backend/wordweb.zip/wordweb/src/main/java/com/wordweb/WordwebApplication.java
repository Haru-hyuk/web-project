package com.wordweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WordwebApplication {

    public static void main(String[] args) {
        SpringApplication.run(WordwebApplication.class, args);
    }
}
